package domain.organizacion;

public class Duenio {
}
