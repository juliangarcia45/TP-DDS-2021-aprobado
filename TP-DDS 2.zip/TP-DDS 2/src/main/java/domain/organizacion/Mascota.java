package domain.organizacion;

public class Mascota {
}
