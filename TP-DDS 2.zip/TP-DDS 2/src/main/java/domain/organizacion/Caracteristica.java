package domain.organizacion;

public class Caracteristica {

}
