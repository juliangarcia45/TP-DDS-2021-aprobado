package domain.organizacion;

public class Documento {
    private int numero;
    private String tipo;
}
