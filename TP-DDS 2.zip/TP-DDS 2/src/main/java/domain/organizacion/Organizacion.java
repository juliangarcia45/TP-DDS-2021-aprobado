package domain.organizacion;

import domain.autenticacion.Usuario;

import java.util.List;

public class Organizacion {
    private List<Usuario> usuarios;

}
