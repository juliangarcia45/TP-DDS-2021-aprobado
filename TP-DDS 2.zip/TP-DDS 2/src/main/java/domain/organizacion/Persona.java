package domain.organizacion;

import domain.notificacion.Contacto;
import java.util.Date;

public class Persona {
    private String apellido;
    private Contacto contacto;
    private Documento documento;
    private Date fecha;


}
