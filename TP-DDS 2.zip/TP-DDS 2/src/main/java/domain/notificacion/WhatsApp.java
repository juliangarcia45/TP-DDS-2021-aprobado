package domain.notificacion;

public class WhatsApp implements FormaDeNotificacion{
    @Override
    public void notificar() {

    }
}
