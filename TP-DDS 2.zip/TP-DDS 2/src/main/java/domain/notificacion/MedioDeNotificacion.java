package domain.notificacion;


public class MedioDeNotificacion  {
    private Contacto contactoANotificar;
    private FormaDeNotificacion estrategiaNotificacion;

    private void cambiarFormaDeNotificacion(FormaDeNotificacion formaDeNotificacion){

    }
    private void notificar(){

    }
}
