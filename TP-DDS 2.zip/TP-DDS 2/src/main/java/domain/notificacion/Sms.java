package domain.notificacion;

public class Sms implements FormaDeNotificacion {
    @Override
    public void notificar() {

    }
}
