package domain.notificacion;

public class Email implements FormaDeNotificacion{
    @Override
    public void notificar() {

    }
}
