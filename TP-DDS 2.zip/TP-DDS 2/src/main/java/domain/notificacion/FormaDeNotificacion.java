package domain.notificacion;

public interface FormaDeNotificacion {

     void notificar();

}
