package domain.autenticacion;

public class Administrador {

}
