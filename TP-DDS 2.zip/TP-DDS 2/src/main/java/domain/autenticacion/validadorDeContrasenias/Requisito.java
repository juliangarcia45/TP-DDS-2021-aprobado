package domain.autenticacion.validadorDeContrasenias;

public interface Requisito {
    boolean validar(String contrasenia);
}
