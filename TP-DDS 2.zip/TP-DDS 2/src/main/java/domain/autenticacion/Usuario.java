package domain.autenticacion;

public class Usuario {
    private String usuario;
    private String contrasenia;

    public Usuario(String usuario, String contrasenia) {
        this.usuario = usuario;
        this.contrasenia = contrasenia;
    }
}
